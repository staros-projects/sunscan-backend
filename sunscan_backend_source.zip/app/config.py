# INTI configuration

# Language setting
# LG=1 for French, LG=2 for English
LG = 1

# Set Low dynamic range mode
# If False, INTI operates in normal mode
# If True, INTI adapts to low dynamic range
LowDyn = True